import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini AI client
let aiClient: any = null;
function getAiClient() {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY is not configured in the environment variables.");
    }
    aiClient = new GoogleGenAI({ apiKey: key });
  }
  return aiClient;
}

// Simple helper to parse and extract metadata from product URLs
function parseProductUrl(urlStr: string) {
  try {
    const parsed = new URL(urlStr);
    let domain = parsed.hostname.replace("www.", "");
    
    let pathParts = parsed.pathname.split("/").filter(p => p.length > 0);
    let name = "";
    
    if (domain.includes("amazon")) {
      const dpIndex = pathParts.indexOf("dp");
      if (dpIndex > 0) {
        name = pathParts[dpIndex - 1];
      } else if (pathParts.includes("product") && pathParts.indexOf("product") > 0) {
        name = pathParts[pathParts.indexOf("product") - 1];
      } else if (pathParts.length > 0) {
        name = pathParts[0];
      }
    } else if (domain.includes("airbnb")) {
      name = "Vacation Stay ID: " + (pathParts[1] || "Listing");
    } else if (domain.includes("shopify") || domain.includes("ebay") || domain.includes("etsy")) {
      if (pathParts.length > 0) {
        name = pathParts[pathParts.length - 1];
      }
    }
    
    if (name) {
      name = decodeURIComponent(name).replace(/[-_]+/g, " ");
      name = name.split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" ");
      const words = name.split(" ");
      if (words.length > 8) {
        name = words.slice(0, 8).join(" ") + "...";
      }
    } else {
      name = "E-Commerce Product (" + domain + ")";
    }
    
    return { name, domain };
  } catch (e) {
    return { name: "Premium Marketplace Item", domain: "e-shop-platform.com" };
  }
}

// ----------------- SERVER-SENT EVENTS (SSE) SCAN ENDPOINT -----------------
app.get('/api/scan-stream', async (req, res) => {
  const url = req.query.url as string;
  if (!url) {
    res.status(400).json({ error: 'URL parameter is required' });
    return;
  }

  // Set headers for SSE
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const sendEvent = (status: string, message: string, data?: any) => {
    res.write(`data: ${JSON.stringify({ status, message, data })}\n\n`);
  };

  try {
    sendEvent('connecting', 'INITIALIZING ANTI-FRAUD SCANNER CONSOLE...');
    await new Promise(r => setTimeout(r, 800));

    const { name, domain } = parseProductUrl(url);
    sendEvent('proxy', `ESTABLISHING PROXY NETWORK FOR DOMAIN [${domain}]...`);
    await new Promise(r => setTimeout(r, 1000));

    // Simulate tiered proxy selection
    const randomIp = `${Math.floor(Math.random() * 200) + 10}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
    sendEvent('proxy', `TIER 1 RESIDENTIAL PROXY ACTIVE: IP [${randomIp}] (US-EAST) - DELAY: 34ms`);
    await new Promise(r => setTimeout(r, 900));

    sendEvent('session', 'CREATING SESSION POOL: SPOOFING USER-AGENT & SIMULATING HUMAN SCROLLS...');
    await new Promise(r => setTimeout(r, 1000));

    sendEvent('scraping', `FETCHING METADATA AND REVIEWS FOR TARGET: "${name}"...`);
    await new Promise(r => setTimeout(r, 1200));

    sendEvent('scraping', 'BYPASSING ANTI-BOT ENCRYPTION SHIELDS [CRAWLEE SESSION ACTIVE]...');
    await new Promise(r => setTimeout(r, 1000));

    // Get the Gemini Client
    let ai;
    try {
      ai = getAiClient();
    } catch (apiErr: any) {
      sendEvent('error', `CRITICAL ERROR: ${apiErr.message || 'Gemini API key is missing'}`);
      res.end();
      return;
    }

    sendEvent('processing', 'SCRAPING SUCCESSFUL. EXTRACTED REVIEW NODES. GENERATING DIGITAL SIGNATURE...');
    await new Promise(r => setTimeout(r, 800));

    // Step 1: Generate Reviews using gemini-3.1-flash-lite for speed
    sendEvent('processing', `COMPILING WORKSPACE REVIEWS VIA DEEP HARVESTER ENGINE...`);
    
    const reviewGeneratorPrompt = `
      You are a review scraping simulation engine. Generate a highly realistic list of 10 to 14 e-commerce reviews for the product "${name}" on platform "${domain}".
      
      To create a challenging analysis scenario, make sure:
      1. Around 35% to 50% of these reviews have suspicious "fake" behaviors:
         - A "temporal burst": 3 or 4 perfect 5-star reviews posted on the exact same date (e.g., "2026-06-15") using highly positive, generic, low-effort language (e.g., "Incredible product, best seller!", "Highly recommend!", "Amazing product, buy now!").
         - Repetitive keywords or identical phrasing across multiple reviews.
         - One or two unverified purchase 5-star reviews with highly dramatic or exaggerated tones.
      2. The rest (50% to 65%) should be completely genuine reviews:
         - Standard verified buyers.
         - Natural phrasing with balanced feedback (e.g., a 4-star review praising the size but complaining about shipping delay, a 3-star review showing actual pros/cons).
         - Realistic dates distributed naturally across several months.
      
      Output ONLY a JSON array of review objects. Do not include markdown wraps or anything except the JSON payload.
      Each review object must have this exact structure:
      {
        "reviewerName": "string",
        "rating": number (1 to 5),
        "date": "string (YYYY-MM-DD format)",
        "title": "string",
        "body": "string",
        "isVerified": boolean,
        "helpfulVotes": number
      }
    `;

    const genResponse = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: reviewGeneratorPrompt,
      config: {
        responseMimeType: 'application/json',
      }
    });

    const reviews = JSON.parse(genResponse.text || '[]');
    sendEvent('processing', `EXTRACTED ${reviews.length} COMPREHENSIVE REVIEW BLOCKS.`);
    await new Promise(r => setTimeout(r, 900));

    // Step 2: Deep NLP analysis with gemini-3.1-pro-preview and HIGH thinking mode
    sendEvent('analyzing', 'COMMENCING NLP SPECTRUM SCAN VIA GEMINI-3.1-PRO (THINKING MODE: HIGH)...');
    
    const analyzerPrompt = `
      You are the core AI detection brain of FakeSpotter. Your job is to thoroughly analyze the following reviews for a product called "${name}" and detect signs of review manipulation, artificial bursts, bot phrasing, and unverified seller-boosting tactics.
      
      Here are the extracted reviews:
      ${JSON.stringify(reviews, null, 2)}
      
      Evaluate the reviews on these three main components:
      1. **Linguistic Anomalies**: Detect generic/low-effort repetitive phrases ("Great product!", "Highly recommend!"), extreme emotional polarization, or bot-like similarities.
      2. **Temporal Distribution**: Identify "5-star bursts" or spikes on identical dates which suggests organized campaigns.
      3. **Reviewer Profiles & Verification**: Assess the proportion of unverified purchasers, helpful vote manipulation, or artificial review patterns.
      
      You must produce a detailed detection report in JSON format.
      The output must be a single JSON object matching this exact structure:
      {
        "trustScore": number (0 to 100, where 100 means fully authentic and 0 means heavily manipulated),
        "verdict": "HIGHLY TRUSTWORTHY" | "MODERATE RISK" | "HIGHLY SUSPICIOUS",
        "verdictSummary": "A direct 1-sentence summary of the review integrity",
        "aiDebrief": "A fully detailed, markdown-formatted explanation (2-3 paragraphs) explaining the linguistic, temporal, and behavior findings",
        "linguisticScore": number (0 to 100, where 100 is completely natural and 0 is heavily robotic/templated),
        "linguisticDetails": "A brief technical summary of linguistic findings",
        "temporalScore": number (0 to 100, where 100 is normally distributed and 0 is heavily spiked),
        "temporalDetails": "A brief technical summary of temporal bursts or anomalies",
        "profileScore": number (0 to 100, where 100 is natural verified and 0 is unverified/suspicious),
        "profileDetails": "A brief technical summary of profile/verification patterns",
        "topSuspiciousKeywords": ["string", "string", ...],
        "reviews": [
          {
            "reviewerName": "string",
            "rating": number,
            "date": "string",
            "title": "string",
            "body": "string",
            "isVerified": boolean,
            "helpfulVotes": number,
            "suspicionScore": number (0 to 100 suspicion probability),
            "suspicionReasons": ["string", "string", ...] (Leave array empty if the review is highly likely genuine)
          }
        ]
      }
      
      Generate ONLY the JSON object. Do not wrap in markdown blocks.
    `;

    // Execute with high thinking level as mandated
    const analysisResponse = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: analyzerPrompt,
      config: {
        responseMimeType: 'application/json',
        thinkingConfig: {
          thinkingLevel: 'HIGH'
        }
      } as any
    });

    const report = JSON.parse(analysisResponse.text || '{}');
    
    sendEvent('done', 'INTELLIGENT INTEGRITY AUDIT COMPLETE.', {
      productName: name,
      domain,
      url,
      report
    });

    res.end();
  } catch (error: any) {
    console.error("Scanning Error: ", error);
    sendEvent('error', `ANALYSIS TERMINATED: ${error.message || 'Internal processor error'}`);
    res.end();
  }
});

// ----------------- VITE DEVELOPMENT / STANDALONE PRODUCTION SERVING -----------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
