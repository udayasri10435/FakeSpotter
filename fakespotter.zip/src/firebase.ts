import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, collection, doc, setDoc, getDoc, getDocs, query, where, orderBy, limit, addDoc } from 'firebase/firestore';

// Hardcoded or dynamically read from the firebase-applet-config file
// Since this config is injected, we can define it directly here
const firebaseConfig = {
  projectId: "totemic-router-tdpgw",
  appId: "1:300439947806:web:4fbe21aa0fe36d95693c0f",
  apiKey: "AIzaSyArOo9uKEvhOzEABTqFU60-x-X14Z0w_X4",
  authDomain: "totemic-router-tdpgw.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-fakespotter-f470240c-4569-4057-b31a-c7de31ae6550",
  storageBucket: "totemic-router-tdpgw.firebasestorage.app",
  messagingSenderId: "300439947806",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

// Custom sign-in with redirect fallback or popup
export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error("Error signing in with Google: ", error);
    throw error;
  }
};

export const logout = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Error signing out: ", error);
    throw error;
  }
};
