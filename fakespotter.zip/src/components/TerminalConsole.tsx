import { useEffect, useRef } from 'react';
import { Terminal, Shield, Eye, Database, Search, Sparkles, Loader2, AlertTriangle } from 'lucide-react';

interface LogLine {
  status: string;
  message: string;
  timestamp: string;
}

interface TerminalConsoleProps {
  logs: LogLine[];
  activeStep: string;
  onAbort?: () => void;
}

export default function TerminalConsole({ logs, activeStep, onAbort }: TerminalConsoleProps) {
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const getStepIcon = (status: string) => {
    switch (status) {
      case 'connecting':
        return <Terminal className="h-4 w-4 text-slate-400" />;
      case 'proxy':
        return <Shield className="h-4 w-4 text-slate-400" />;
      case 'session':
        return <Eye className="h-4 w-4 text-slate-400" />;
      case 'scraping':
        return <Database className="h-4 w-4 text-amber-400" />;
      case 'processing':
        return <Search className="h-4 w-4 text-slate-400" />;
      case 'analyzing':
        return <Sparkles className="h-4 w-4 text-purple-400" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-rose-400" />;
      default:
        return <Loader2 className="h-4 w-4 text-slate-400 animate-spin" />;
    }
  };

  const getLogColorClass = (status: string) => {
    switch (status) {
      case 'connecting':
        return 'text-slate-400';
      case 'proxy':
        return 'text-slate-300';
      case 'session':
        return 'text-slate-300';
      case 'scraping':
        return 'text-amber-400';
      case 'processing':
        return 'text-slate-300';
      case 'analyzing':
        return 'text-purple-300 font-medium';
      case 'done':
        return 'text-emerald-400 font-semibold';
      case 'error':
        return 'text-rose-400 bg-rose-950/20 px-2 py-0.5 rounded border border-rose-900/30 font-semibold';
      default:
        return 'text-slate-300';
    }
  };

  return (
    <div className="w-full bg-slate-900 rounded-2xl border border-slate-950 shadow-xl overflow-hidden relative">
      {/* Terminal Title Bar */}
      <div className="bg-slate-950 border-b border-slate-900 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="flex space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-800 inline-block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-slate-800 inline-block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-slate-800 inline-block"></span>
          </div>
          <span className="text-xs font-mono font-medium text-slate-400 ml-2 select-none">
            INTEGRITY_AUDIT_CONSOLE
          </span>
        </div>
        <div className="flex items-center space-x-3">
          <span className="flex h-1.5 w-1.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] font-mono text-slate-300 tracking-wider uppercase">
            {activeStep || 'STANDBY'}
          </span>
        </div>
      </div>

      {/* Terminal Content Screen */}
      <div className="p-5 h-[360px] overflow-y-auto font-mono text-xs space-y-3.5 bg-slate-950 select-text relative">
        {logs.map((log, index) => (
          <div key={index} className="flex items-start space-x-2.5 leading-relaxed relative z-10">
            <span className="text-slate-600 select-none text-[9px] mt-0.5">[{log.timestamp}]</span>
            <div className="flex items-center justify-center p-0.5 rounded bg-slate-900 border border-slate-800 shrink-0">
              {getStepIcon(log.status)}
            </div>
            <div className={`flex-1 break-words ${getLogColorClass(log.status)}`}>
              {log.message}
            </div>
          </div>
        ))}

        {/* Loading Spinner for current active task */}
        {activeStep && activeStep !== 'done' && activeStep !== 'error' && (
          <div className="flex items-center space-x-2 text-slate-400 pl-11">
            <Loader2 className="h-3 w-3 animate-spin text-slate-400" />
            <span className="italic text-[10px] text-slate-500">Processing live reviews stream...</span>
          </div>
        )}

        <div ref={terminalEndRef} />
      </div>

      {/* Bottom Info Banner */}
      <div className="bg-slate-950 border-t border-slate-900 px-4 py-3 flex flex-col sm:flex-row items-center justify-between text-[10px] font-mono text-slate-500">
        <div className="mb-2 sm:mb-0">
          STATUS: <span className="text-slate-400 font-bold">DEEP WEB EXTRACTION SECURE</span>
        </div>
        {onAbort && activeStep && activeStep !== 'done' && activeStep !== 'error' && (
          <button
            onClick={onAbort}
            className="text-rose-400 hover:text-rose-300 font-bold px-3 py-1 rounded-full border border-rose-950 bg-rose-950/40 hover:bg-rose-950/80 transition-all cursor-pointer"
          >
            ABORT SCAN
          </button>
        )}
      </div>
    </div>
  );
}
