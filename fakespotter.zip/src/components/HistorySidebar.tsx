import { ScanHistoryItem } from '../types';
import { Clock, Trash2, ChevronRight, ShieldCheck, ShieldAlert, AlertTriangle, Shield } from 'lucide-react';

interface HistorySidebarProps {
  history: ScanHistoryItem[];
  activeId: string | null;
  onSelect: (item: ScanHistoryItem) => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
}

export default function HistorySidebar({
  history,
  activeId,
  onSelect,
  onDelete,
  onClearAll,
}: HistorySidebarProps) {
  const getScoreColor = (score: number, isActive: boolean) => {
    if (isActive) {
      if (score >= 75) return 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10';
      if (score >= 45) return 'text-amber-300 border-amber-500/30 bg-amber-500/10';
      return 'text-rose-300 border-rose-500/30 bg-rose-500/10';
    }
    if (score >= 75) return 'text-emerald-600 border-emerald-200 bg-emerald-50';
    if (score >= 45) return 'text-amber-600 border-amber-200 bg-amber-50';
    return 'text-rose-600 border-rose-200 bg-rose-50';
  };

  const getVerdictIcon = (verdict: string, isActive: boolean) => {
    switch (verdict) {
      case 'HIGHLY TRUSTWORTHY':
        return <ShieldCheck className={`h-3.5 w-3.5 shrink-0 ${isActive ? 'text-emerald-300' : 'text-emerald-500'}`} />;
      case 'MODERATE RISK':
        return <AlertTriangle className={`h-3.5 w-3.5 shrink-0 ${isActive ? 'text-amber-300' : 'text-amber-500'}`} />;
      default:
        return <ShieldAlert className={`h-3.5 w-3.5 shrink-0 ${isActive ? 'text-rose-300' : 'text-rose-500'}`} />;
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-col h-full space-y-4 minimal-shadow">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center space-x-2">
          <Clock className="h-4 w-4 text-slate-400" />
          <h3 className="font-display font-bold text-slate-800 text-sm tracking-tight uppercase">Audit History</h3>
        </div>
        {history.length > 0 && (
          <button
            onClick={onClearAll}
            className="text-[10px] font-mono font-bold text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
          >
            CLEAR ALL
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[350px] md:max-h-none pr-1">
        {history.length === 0 ? (
          <div className="text-center py-10 px-4 rounded-xl border border-dashed border-slate-200 bg-slate-50/50">
            <Shield className="h-8 w-8 text-slate-300 mx-auto mb-2" />
            <p className="text-xs text-slate-500 font-mono">No audits recorded yet</p>
            <p className="text-[10px] text-slate-400 font-mono mt-1">Initiate a deep scan to save results</p>
          </div>
        ) : (
          history.map((item) => {
            const reportId = item.id || item.timestamp?.toString() || '';
            const isActive = activeId === reportId;
            const scoreStyles = getScoreColor(item.report.trustScore, isActive);

            return (
              <div
                key={reportId}
                className={`group rounded-xl border p-3 flex items-start justify-between gap-3 transition-all duration-200 select-none ${
                  isActive
                    ? 'bg-slate-900 border-slate-900 text-white minimal-shadow-md'
                    : 'bg-slate-50 border-slate-100 hover:border-slate-200 text-slate-700'
                }`}
              >
                {/* Clickable Area */}
                <button
                  onClick={() => onSelect(item)}
                  className="flex-1 text-left space-y-1 min-w-0 cursor-pointer"
                >
                  <div className="flex items-center space-x-1.5 min-w-0">
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border uppercase tracking-wide truncate max-w-[80px] ${
                      isActive ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-white border-slate-200 text-slate-500'
                    }`}>
                      {item.domain}
                    </span>
                    <span className={`text-[10px] font-mono ${isActive ? 'text-slate-400' : 'text-slate-400'}`}>
                      {item.timestamp ? new Date(item.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : ''}
                    </span>
                  </div>

                  <h4 className={`font-display font-semibold text-xs truncate transition-colors ${
                    isActive ? 'text-white' : 'text-slate-800 group-hover:text-slate-900'
                  }`}>
                    {item.productName}
                  </h4>

                  <div className="flex items-center space-x-2">
                    {/* Verdict Icon */}
                    {getVerdictIcon(item.report.verdict, isActive)}

                    {/* Trust Score badge */}
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${scoreStyles}`}>
                      TRUST: {item.report.trustScore}%
                    </span>
                  </div>
                </button>

                {/* Trash Delete Action */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (item.id) onDelete(item.id);
                  }}
                  className={`p-1.5 rounded border transition-all cursor-pointer self-center shrink-0 ${
                    isActive
                      ? 'bg-slate-800 border-slate-700 text-slate-400 hover:text-rose-400 hover:border-rose-500/30'
                      : 'bg-white border-slate-200 text-slate-400 hover:text-rose-500 hover:border-rose-200'
                  }`}
                  title="Remove Scan Log"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            );
          })
        )}
      </div>

      <div className="border-t border-slate-100 pt-3 text-[10px] font-mono text-slate-400 flex items-center justify-between select-none">
        <span>PERSISTENCE: <span className="text-emerald-600 font-bold">LIVE</span></span>
        <span>{history.length} AUDITS</span>
      </div>
    </div>
  );
}
