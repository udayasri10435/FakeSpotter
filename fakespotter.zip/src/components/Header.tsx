import { useState } from 'react';
import { ShieldCheck, ShieldAlert, Sparkles, LogIn, LogOut, User, Zap } from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';

interface HeaderProps {
  user: FirebaseUser | null;
  isPro: boolean;
  scansLeft: number;
  maxScans: number;
  onSignIn: () => void;
  onSignOut: () => void;
  onTogglePro: () => void;
}

export default function Header({
  user,
  isPro,
  scansLeft,
  maxScans,
  onSignIn,
  onSignOut,
  onTogglePro,
}: HeaderProps) {
  return (
    <header className="border-b border-slate-100 bg-white/85 backdrop-blur-md sticky top-0 z-40 minimal-shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-3">
          <div className="relative flex h-8 w-8 items-center justify-center rounded-md bg-slate-900 text-white">
            <div className="w-2.5 h-2.5 bg-white rotate-45"></div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-display font-bold text-lg tracking-tight text-slate-900">
                FAKESPOTTER
              </span>
              <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border border-slate-200 bg-slate-50 text-slate-500 tracking-wider">
                v2.0
              </span>
            </div>
            <p className="text-[9px] text-slate-400 font-mono tracking-wider hidden sm:block">
              INTELLIGENT INTEGRITY DETECTOR
            </p>
          </div>
        </div>

        {/* Dynamic Navigation Options & User Controls */}
        <div className="flex items-center space-x-4">
          {/* Credit Tracker Widget */}
          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-mono text-slate-600">
            {isPro ? (
              <div className="flex items-center space-x-1.5 text-amber-600 font-semibold">
                <Zap className="h-3.5 w-3.5 fill-amber-500/20" />
                <span className="tracking-tight">PRO ACTIVE</span>
              </div>
            ) : (
              <div className="flex items-center space-x-1.5">
                <span className="text-[10px] text-slate-400">SCANS:</span>
                <span className="font-bold text-slate-900">{scansLeft}</span>
                <span className="text-slate-300">/</span>
                <span className="text-slate-600">{maxScans}</span>
                <span className="text-[10px] text-slate-400 hidden md:inline">FREE</span>
              </div>
            )}
          </div>

          {/* Pro Upgrade Trigger */}
          <button
            onClick={onTogglePro}
            className={`flex items-center space-x-1 px-4 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all duration-200 cursor-pointer ${
              isPro
                ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                : 'bg-slate-900 hover:bg-slate-800 text-white'
            }`}
          >
            {isPro ? (
              <span>Downgrade</span>
            ) : (
              <>
                <Sparkles className="h-3 w-3" />
                <span>Upgrade to Pro</span>
              </>
            )}
          </button>

          {/* Auth Controls */}
          {user ? (
            <div className="flex items-center space-x-3 pl-3 border-l border-slate-200">
              <div className="hidden md:block text-right">
                <p className="text-xs font-semibold text-slate-800">{user.displayName || 'Auditor User'}</p>
                <p className="text-[9px] font-mono text-slate-400">{user.email}</p>
              </div>
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'Avatar'}
                  referrerPolicy="no-referrer"
                  className="h-8 w-8 rounded-full border border-slate-200 hover:border-slate-300 transition-colors"
                />
              ) : (
                <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center border border-slate-200">
                  <User className="h-4 w-4 text-slate-500" />
                </div>
              )}
              <button
                onClick={onSignOut}
                title="Sign Out"
                className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-500 hover:text-rose-500 hover:border-rose-200 transition-all cursor-pointer"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onSignIn}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-xs font-mono font-medium text-slate-600 hover:text-slate-900 hover:border-slate-300 transition-all cursor-pointer"
            >
              <LogIn className="h-4 w-4 text-slate-500" />
              <span>SIGN IN</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
