import { useState } from 'react';
import { jsPDF } from 'jspdf';
import { ScanReport, Review } from '../types';
import { 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  ThumbsUp, 
  ExternalLink, 
  MessageSquare, 
  Clock, 
  UserCheck, 
  Sparkles, 
  FileText, 
  Search, 
  TrendingUp, 
  CheckCircle, 
  Slash,
  Download,
  Share2
} from 'lucide-react';

interface ReportDashboardProps {
  productName: string;
  domain: string;
  url: string;
  report: ScanReport;
  reportId?: string;
}

// Simple helper to parse basic markdown (**bold** and newlines) safely
function FormattedDebrief({ text }: { text: string }) {
  if (!text) return null;
  
  const paragraphs = text.split('\n\n').filter(p => p.trim().length > 0);
  
  return (
    <div className="space-y-4 text-slate-700 leading-relaxed text-sm select-text">
      {paragraphs.map((para, i) => {
        // Parse bold formatting **text**
        const parts = para.split(/\*\*([^*]+)\*\*/g);
        return (
          <p key={i}>
            {parts.map((part, j) => {
              // Odd indices are bold because of the splitting pattern
              if (j % 2 === 1) {
                return <strong key={j} className="text-slate-900 font-semibold bg-slate-50 px-1 py-0.5 rounded border border-slate-200/60">{part}</strong>;
              }
              return part;
            })}
          </p>
        );
      })}
    </div>
  );
}

export default function ReportDashboard({ productName, domain, url, report, reportId }: ReportDashboardProps) {
  const [filter, setFilter] = useState<'all' | 'suspicious' | 'genuine'>('all');
  const [ratingFilter, setRatingFilter] = useState<number | 'all'>('all');
  const [selectedTimelineDate, setSelectedTimelineDate] = useState<string | null>(null);
  const [hoveredTimelineDate, setHoveredTimelineDate] = useState<string | null>(null);

  const {
    trustScore,
    verdict,
    verdictSummary,
    aiDebrief,
    linguisticScore,
    linguisticDetails,
    temporalScore,
    temporalDetails,
    profileScore,
    profileDetails,
    topSuspiciousKeywords,
    reviews
  } = report;

  // Group and sort reviews by date chronologically
  const timelineData = Object.values(
    reviews.reduce((acc: { [key: string]: { date: string; dateObj: Date; total: number; suspicious: number; genuine: number } }, r) => {
      const dStr = r.date || 'Unknown';
      const formattedDate = dStr.split('T')[0]; // Safe formatting
      let dateObj = new Date();
      try {
        const parsed = new Date(dStr);
        if (!isNaN(parsed.getTime())) {
          dateObj = parsed;
        }
      } catch (e) {
        // Fallback
      }

      if (!acc[formattedDate]) {
        acc[formattedDate] = {
          date: formattedDate,
          dateObj,
          total: 0,
          suspicious: 0,
          genuine: 0
        };
      }

      acc[formattedDate].total += 1;
      if (r.suspicionScore >= 40) {
        acc[formattedDate].suspicious += 1;
      } else {
        acc[formattedDate].genuine += 1;
      }

      return acc;
    }, {})
  ).sort((a, b) => a.dateObj.getTime() - b.dateObj.getTime());

  // Max value of reviews on a single day for scale, minimum is 4 for empty cushion
  const maxVal = Math.max(4, ...timelineData.map(d => d.total));

  // Find Peak Activity Date
  const peakDay = timelineData.reduce((prev, current) => {
    if (!prev) return current;
    return prev.total > current.total ? prev : current;
  }, null as typeof timelineData[0] | null);

  // Identify anomalies: Days with >= 3 total reviews OR >= 2 fakes making up >= 60% of reviews
  const anomalies = timelineData.filter(d => d.total >= 3 || (d.suspicious >= 2 && d.suspicious / d.total >= 0.6));

  const formatDateLabel = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const mIdx = parseInt(parts[1], 10) - 1;
        if (mIdx >= 0 && mIdx < 12) {
          return `${months[mIdx]} ${parseInt(parts[2], 10)}`;
        }
      }
    } catch(e) {}
    return dateStr;
  };

  // Color interpolation for dynamic color coding (from red to yellow/amber to green)
  const getInterpolatedColor = (score: number) => {
    if (score < 50) {
      const ratio = score / 50;
      const r = Math.round(239 + (245 - 239) * ratio); // #ef4444 (239, 68, 68) to #f59e0b (245, 158, 11)
      const g = Math.round(68 + (158 - 68) * ratio);
      const b = Math.round(68 + (11 - 68) * ratio);
      return `rgb(${r}, ${g}, ${b})`;
    } else {
      const ratio = (score - 50) / 50;
      const r = Math.round(245 + (16 - 245) * ratio); // #f59e0b (245, 158, 11) to #10b981 (16, 185, 129)
      const g = Math.round(158 + (185 - 158) * ratio);
      const b = Math.round(11 + (129 - 11) * ratio);
      return `rgb(${r}, ${g}, ${b})`;
    }
  };

  const activeColor = getInterpolatedColor(trustScore);

  const getIndicatorDotCoords = (score: number, r: number = 74, cx: number = 96, cy: number = 96) => {
    const angle = (score / 100) * 360;
    const angleRad = (angle - 90) * (Math.PI / 180); // Start at top
    return {
      x: cx + r * Math.cos(angleRad),
      y: cy + r * Math.sin(angleRad)
    };
  };

  const dotCoords = getIndicatorDotCoords(trustScore);

  const ticks = Array.from({ length: 10 }).map((_, idx) => {
    const angle = (idx / 10) * 360 - 90;
    const angleRad = angle * (Math.PI / 180);
    const x1 = 96 + 82 * Math.cos(angleRad);
    const y1 = 96 + 82 * Math.sin(angleRad);
    const x2 = 96 + 86 * Math.cos(angleRad);
    const y2 = 96 + 86 * Math.sin(angleRad);
    return { x1, y1, x2, y2, value: idx * 10 };
  });

  const [copied, setCopied] = useState(false);

  const handleShare = () => {
    const origin = window.location.origin;
    const path = window.location.pathname;
    const shareUrl = reportId ? `${origin}${path}?reportId=${reportId}` : window.location.href;

    const text = `🔍 FAKESPOTTER INTEGRITY AUDIT REPORT
----------------------------------------------
📦 Product: ${productName}
🌐 Platform/Domain: ${domain}
🛡️ Verdict: ${verdict}
🎯 Trust Score: ${trustScore}/100

📈 Core Diagnostics:
- Linguistic Scrutiny: ${linguisticScore}%
- Temporal Velocity: ${temporalScore}%
- Reviewer Profiling: ${profileScore}%

🔗 Explore full interactive charts & timeline:
${shareUrl}

*Generated securely by Fakespotter via Gemini thinking models.*`;

    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy text to clipboard:', err);
    });
  };

  const handleExportPDF = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    let y = 20;
    const margin = 15;
    const pageWidth = 210;
    const contentWidth = pageWidth - (margin * 2); // 180

    const drawHeaderAndFooter = () => {
      // Small running header
      doc.setFont('Helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184); // slate-400
      doc.text('FAKESPOTTER REVIEW INTEGRITY AUDIT REPORT', margin, 12);
      doc.setDrawColor(241, 245, 249); // slate-100
      doc.setLineWidth(0.3);
      doc.line(margin, 14, pageWidth - margin, 14);

      // Running footer
      doc.line(margin, 282, pageWidth - margin, 282);
      doc.text('CONFIDENTIAL - FOR RESEARCH PURPOSES ONLY', margin, 288);
      const pageCount = (doc as any).internal.getNumberOfPages();
      doc.text(`Page ${pageCount}`, pageWidth - margin - 15, 288);
    };

    // Helper for printing wrapped text and tracking Y position
    const addWrappedText = (text: string, fontSize: number, style: 'normal' | 'bold' | 'italic' = 'normal', color: [number, number, number] = [15, 23, 42], lineHeight: number = 6) => {
      doc.setFont('Helvetica', style);
      doc.setFontSize(fontSize);
      doc.setTextColor(color[0], color[1], color[2]);
      
      const lines = doc.splitTextToSize(text, contentWidth);
      for (let i = 0; i < lines.length; i++) {
        if (y > 270) {
          doc.addPage();
          drawHeaderAndFooter();
          y = 25;
          doc.setFont('Helvetica', style);
          doc.setFontSize(fontSize);
          doc.setTextColor(color[0], color[1], color[2]);
        }
        doc.text(lines[i], margin, y);
        y += lineHeight;
      }
    };

    const checkPageSpace = (neededHeight: number) => {
      if (y + neededHeight > 270) {
        doc.addPage();
        drawHeaderAndFooter();
        y = 25;
      }
    };

    // Initial header and footer for the first page
    drawHeaderAndFooter();
    y = 25;

    // Document Main Title
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(22);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text('FAKESPOTTER REPORT', margin, y);
    y += 5;

    // Subtitle / Tagline
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text('INTELLIGENT REVIEW INTEGRITY & BEHAVIORAL DETECTOR', margin, y);
    y += 8;

    // Separator line
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);
    y += 8;

    // Metadata block
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text('PRODUCT:', margin, y);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(51, 65, 85);
    // Wrap product name in case it's very long
    const prodLines = doc.splitTextToSize(productName, contentWidth - 30);
    doc.text(prodLines, margin + 30, y);
    y += (prodLines.length * 5) + 2;

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text('URL:', margin, y);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(30, 41, 59); // slate-800
    const urlLines = doc.splitTextToSize(url, contentWidth - 30);
    doc.text(urlLines, margin + 30, y);
    y += (urlLines.length * 5) + 2;

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text('DOMAIN:', margin, y);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(10);
    doc.text(domain, margin + 30, y);
    y += 6;

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text('DATE:', margin, y);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(10);
    doc.text(new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }), margin + 30, y);
    y += 10;

    // Section 1: Trust Score Card
    checkPageSpace(45);
    // Draw card box
    doc.setFillColor(248, 250, 252); // slate-50
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.roundedRect(margin, y, contentWidth, 38, 3, 3, 'FD');

    // Score inside card
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(28);
    // Use active color rgb!
    let rgb = [5, 150, 105]; // Green by default
    if (trustScore < 45) {
      rgb = [220, 38, 38]; // Red
    } else if (trustScore < 75) {
      rgb = [217, 119, 6]; // Amber
    }
    doc.setTextColor(rgb[0], rgb[1], rgb[2]);
    doc.text(`${trustScore}`, margin + 10, y + 16);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text('/ 100 POINTS', margin + 10, y + 23);

    // Vertical separator inside card
    doc.setDrawColor(226, 232, 240);
    doc.line(margin + 55, y + 6, margin + 55, y + 32);

    // Verdict inside card
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(rgb[0], rgb[1], rgb[2]);
    doc.text(verdict, margin + 62, y + 12);

    // Verdict Summary wrap
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(51, 65, 85);
    const summLines = doc.splitTextToSize(verdictSummary, contentWidth - 75);
    doc.text(summLines, margin + 62, y + 18);

    y += 46;

    // Section 2: AI Security Debrief
    checkPageSpace(30);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('GEMINI SECURITY DEBRIEF', margin, y);
    y += 5;
    
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, margin + 30, y);
    y += 6;

    const paragraphs = aiDebrief.split('\n\n').filter((p: string) => p.trim().length > 0);
    for (const para of paragraphs) {
      const cleanPara = para.replace(/\*\*/g, '');
      addWrappedText(cleanPara, 9.5, 'normal', [71, 85, 105], 5.5);
      y += 2; // small gap
    }

    y += 6;

    // Section 3: Dimension Analysis
    checkPageSpace(40);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('DIMENSIONAL ANALYSIS CRITERIA', margin, y);
    y += 5;
    
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, margin + 30, y);
    y += 8;

    const dimensions = [
      { name: 'Linguistic Scrutiny', score: linguisticScore, details: linguisticDetails },
      { name: 'Temporal Distribution', score: temporalScore, details: temporalDetails },
      { name: 'Reviewer Profiling', score: profileScore, details: profileDetails }
    ];

    for (const dim of dimensions) {
      checkPageSpace(28);
      // Small box header
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(margin, y, contentWidth, 6, 1, 1, 'F');
      
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(9.5);
      doc.setTextColor(15, 23, 42);
      doc.text(dim.name.toUpperCase(), margin + 3, y + 4.5);

      let dimRgb = [5, 150, 105];
      if (dim.score < 45) dimRgb = [220, 38, 38];
      else if (dim.score < 75) dimRgb = [217, 119, 6];

      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(dimRgb[0], dimRgb[1], dimRgb[2]);
      doc.text(`SCORE: ${dim.score}%`, pageWidth - margin - 30, y + 4.5);
      
      y += 9;

      addWrappedText(dim.details, 9, 'normal', [71, 85, 105], 5);
      y += 6;
    }

    // Section 4: Suspicious Keywords
    if (topSuspiciousKeywords && topSuspiciousKeywords.length > 0) {
      checkPageSpace(25);
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42);
      doc.text('SUSPICIOUS CORE PHRASES IDENTIFIED', margin, y);
      y += 5;

      doc.setDrawColor(226, 232, 240);
      doc.line(margin, y, margin + 30, y);
      y += 6;

      const keywordsStr = topSuspiciousKeywords.map((kw: string) => `"${kw}"`).join(', ');
      addWrappedText(keywordsStr, 9.5, 'bold', [220, 38, 38], 5);
      y += 8;
    }

    // Section 5: Highlighted Flagged Reviews
    const flaggedReviews = reviews.filter((r: Review) => r.suspicionScore >= 40);
    if (flaggedReviews.length > 0) {
      checkPageSpace(35);
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42);
      doc.text(`FLAGGED REVIEWS (${flaggedReviews.length})`, margin, y);
      y += 5;

      doc.setDrawColor(226, 232, 240);
      doc.line(margin, y, margin + 30, y);
      y += 6;

      for (const review of flaggedReviews) {
        checkPageSpace(45);
        // Draw card boundary
        doc.setFillColor(254, 242, 242); // very soft red background
        doc.setDrawColor(254, 202, 202); // soft red border
        doc.roundedRect(margin, y, contentWidth, 34, 2, 2, 'FD');

        // Reviewer Name & Date
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(153, 27, 27); // dark red
        doc.text(`${review.reviewerName} (${review.isVerified ? 'VERIFIED PURCHASE' : 'UNVERIFIED'})`, margin + 4, y + 5);

        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(127, 29, 29);
        doc.text(`Rating: ${review.rating} Stars | Date: ${review.date}`, margin + 4, y + 9);

        // Suspicion Score Badge
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(220, 38, 38);
        doc.text(`SUSPICION LEVEL: ${review.suspicionScore}%`, pageWidth - margin - 50, y + 5);

        // Title & Review Body Preview
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(15, 23, 42);
        const titleLines = doc.splitTextToSize(review.title, contentWidth - 10);
        doc.text(titleLines, margin + 4, y + 14);

        doc.setFont('Helvetica', 'italic');
        doc.setFontSize(8.5);
        doc.setTextColor(51, 65, 85);
        
        const cleanBody = review.body.length > 180 ? `${review.body.substring(0, 180)}...` : review.body;
        const bodyLines = doc.splitTextToSize(`"${cleanBody}"`, contentWidth - 10);
        doc.text(bodyLines, margin + 4, y + 19);

        // Print reasons
        if (review.suspicionReasons.length > 0) {
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(8);
          doc.setTextColor(185, 28, 28);
          doc.text(`Triggered Flags: ${review.suspicionReasons.slice(0, 2).join(' | ')}`, margin + 4, y + 30);
        }

        y += 38;
      }
    }

    const safeFileName = productName.replace(/[^a-z0-9]/gi, '_').toLowerCase().substring(0, 30);
    doc.save(`fakespotter_audit_${safeFileName}.pdf`);
  };

  // Filter reviews
  const filteredReviews = reviews.filter(review => {
    const isSuspicious = review.suspicionScore >= 40;
    if (filter === 'suspicious' && !isSuspicious) return false;
    if (filter === 'genuine' && isSuspicious) return false;
    
    if (ratingFilter !== 'all' && review.rating !== ratingFilter) return false;
    if (selectedTimelineDate && review.date !== selectedTimelineDate) return false;
    return true;
  });

  // Gauge colors for Clean Minimalism
  const getScoreColor = (score: number) => {
    if (score >= 75) return { text: 'text-emerald-700', border: 'border-emerald-200', bg: 'bg-emerald-50', fill: '#059669', hover: 'hover:border-emerald-300' };
    if (score >= 45) return { text: 'text-amber-700', border: 'border-amber-200', bg: 'bg-amber-50', fill: '#d97706', hover: 'hover:border-amber-300' };
    return { text: 'text-rose-700', border: 'border-rose-200', bg: 'bg-rose-50', fill: '#dc2626', hover: 'hover:border-rose-300' };
  };

  const getVerdictStyles = (v: string) => {
    switch (v) {
      case 'HIGHLY TRUSTWORTHY':
        return {
          bannerBg: 'bg-emerald-50 border-emerald-100',
          badgeText: 'text-emerald-700 bg-emerald-100/50',
          icon: <ShieldCheck className="h-6 w-6 text-emerald-600" />,
          title: 'SECURE: HIGH INTEGRITY',
        };
      case 'MODERATE RISK':
        return {
          bannerBg: 'bg-amber-50 border-amber-100',
          badgeText: 'text-amber-700 bg-amber-100/50',
          icon: <AlertTriangle className="h-6 w-6 text-amber-600" />,
          title: 'CAUTION: POTENTIAL MANIPULATION',
        };
      default:
        return {
          bannerBg: 'bg-rose-50 border-rose-100',
          badgeText: 'text-rose-700 bg-rose-100/50',
          icon: <ShieldAlert className="h-6 w-6 text-rose-600" />,
          title: 'DANGER: HIGHLY SUSPICIOUS',
        };
    }
  };

  const verdictStyles = getVerdictStyles(verdict);
  const coreScoreStyles = getScoreColor(trustScore);

  return (
    <div className="space-y-8 select-none">
      {/* Top Banner with Product Details */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 md:p-6 minimal-shadow flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5 flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] font-mono font-bold tracking-wider text-slate-500 uppercase bg-slate-100 px-2 py-0.5 rounded border border-slate-250">
              {domain}
            </span>
            <span className="text-[9px] font-mono text-slate-400">AUDITED SECURELY</span>
          </div>
          <h2 className="text-xl md:text-2xl font-display font-bold text-slate-900 truncate pr-4">
            {productName}
          </h2>
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-1.5 text-xs font-mono text-slate-400 hover:text-slate-600 transition-colors"
          >
            <span className="truncate max-w-xs md:max-w-md">{url}</span>
            <ExternalLink className="h-3.5 w-3.5 shrink-0" />
          </a>
        </div>

        <div className="flex md:flex-col items-center md:items-end justify-between md:justify-center border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-6 shrink-0 gap-3">
          <div className="text-right">
            <span className="text-[10px] font-mono font-bold text-slate-400 block tracking-wider">TIMESTAMP LOGGED</span>
            <span className="text-sm font-mono font-bold text-slate-700">
              {new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
            </span>
          </div>
          <div className="flex flex-row md:flex-col gap-2 w-full md:w-auto">
            <button
              onClick={handleExportPDF}
              className="inline-flex items-center justify-center space-x-1.5 px-3.5 py-2 text-xs font-bold font-sans rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-900 transition-all cursor-pointer shadow-xs active:scale-95 flex-1 md:flex-initial"
              title="Download printable PDF of this audit report"
            >
              <Download className="h-4 w-4 text-purple-600" />
              <span>Export to PDF</span>
            </button>
            <button
              onClick={handleShare}
              className={`inline-flex items-center justify-center space-x-1.5 px-3.5 py-2 text-xs font-bold font-sans rounded-xl border transition-all cursor-pointer shadow-xs active:scale-95 flex-1 md:flex-initial ${
                copied 
                  ? 'bg-emerald-600 border-emerald-700 text-white' 
                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-900'
              }`}
              title="Copy permanent link & text summary of report to clipboard"
            >
              <Share2 className={`h-4 w-4 ${copied ? 'text-white font-bold animate-ping' : 'text-purple-600'}`} />
              <span>{copied ? 'Copied Summary!' : 'Share Report'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Analysis Panel (Gauge and Debrief) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Trust Gauge Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 flex flex-col items-center justify-center relative overflow-hidden minimal-shadow">
          <div className="absolute top-3 left-3 flex items-center space-x-1">
            <span className="h-1.5 w-1.5 rounded-full bg-slate-400"></span>
            <span className="text-[9px] font-mono text-slate-400 tracking-wider">TRUST INDEX V.2</span>
          </div>

          {/* Glowing Radial Meter */}
          <div className="relative flex items-center justify-center w-48 h-48 my-4">
            {/* Background Circle Track */}
            <svg className="absolute w-full h-full transform -rotate-90">
              <defs>
                <linearGradient id="trustGradient" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#ef4444" />   {/* Red */}
                  <stop offset="50%" stopColor="#f59e0b" />  {/* Amber */}
                  <stop offset="100%" stopColor="#10b981" /> {/* Emerald */}
                </linearGradient>
                <filter id="gaugeShadow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.15" />
                </filter>
              </defs>

              {/* External ticks for high-end dashboard appearance */}
              {ticks.map((tick, idx) => {
                const isHighlighted = tick.value <= trustScore;
                return (
                  <line
                    key={idx}
                    x1={tick.x1}
                    y1={tick.y1}
                    x2={tick.x2}
                    y2={tick.y2}
                    stroke={isHighlighted ? activeColor : '#e2e8f0'}
                    strokeWidth={isHighlighted ? "2" : "1.2"}
                    className="transition-all duration-1000 ease-out"
                  />
                );
              })}

              {/* Main Gray Track */}
              <circle
                cx="96"
                cy="96"
                r="74"
                stroke="#f1f5f9"
                strokeWidth="10"
                fill="transparent"
              />

              {/* Glowing Ambient Background under progress arc */}
              <circle
                cx="96"
                cy="96"
                r="74"
                stroke={activeColor}
                strokeWidth="12"
                fill="transparent"
                strokeDasharray="465"
                strokeDashoffset={465 - (465 * trustScore) / 100}
                strokeLinecap="round"
                opacity="0.1"
                className="transition-all duration-1000 ease-out"
              />

              {/* Foreground Animated Gauge (uses the color-coded dynamic gradient) */}
              <circle
                cx="96"
                cy="96"
                r="74"
                stroke="url(#trustGradient)"
                strokeWidth="10"
                fill="transparent"
                strokeDasharray="465"
                strokeDashoffset={465 - (465 * trustScore) / 100}
                strokeLinecap="round"
                className="transition-all duration-1000 ease-out"
              />

              {/* Outer soft orbit line */}
              <circle
                cx="96"
                cy="96"
                r="84"
                stroke="#f1f5f9"
                strokeWidth="0.5"
                fill="transparent"
                strokeDasharray="4,4"
              />

              {/* Interactive Selector knob / indicator dot */}
              <circle
                cx={dotCoords.x}
                cy={dotCoords.y}
                r="9"
                fill="#ffffff"
                stroke={activeColor}
                strokeWidth="3.5"
                filter="url(#gaugeShadow)"
                className="transition-all duration-1000 ease-out"
              />
              <circle
                cx={dotCoords.x}
                cy={dotCoords.y}
                r="3"
                fill={activeColor}
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="text-center z-10 select-none">
              <span 
                className="text-6xl font-display font-extrabold tracking-tight transition-all duration-1000 block leading-none"
                style={{ color: activeColor }}
              >
                {trustScore}
              </span>
              <span className="text-slate-400 text-[11px] block font-mono font-bold mt-1 tracking-wider">/ 100 PTS</span>
              <span 
                className="text-[9px] font-mono font-extrabold tracking-widest uppercase mt-1 px-2 py-0.5 rounded-full inline-block bg-slate-50 border border-slate-100 shadow-sm"
                style={{ color: activeColor }}
              >
                {trustScore >= 75 ? 'SECURE' : trustScore >= 45 ? 'CAUTION' : 'RISK'}
              </span>
            </div>
          </div>

          {/* Audit Verdict Banner */}
          <div className={`w-full mt-2 p-4 rounded-xl border ${verdictStyles.bannerBg} text-center space-y-1`}>
            <div className="flex items-center justify-center space-x-2">
              <span className={`font-display font-extrabold text-xs tracking-wider uppercase ${coreScoreStyles.text}`}>
                {verdictStyles.title}
              </span>
            </div>
            <p className="text-xs text-slate-600 leading-snug font-medium">{verdictSummary}</p>
          </div>
        </div>

        {/* AI Security Debrief Card */}
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-6 flex flex-col relative minimal-shadow">
          <div className="absolute top-3 left-3 flex items-center space-x-1">
            <Sparkles className="h-3.5 w-3.5 text-purple-500" />
            <span className="text-[9px] font-mono text-slate-400 tracking-wider">GEMINI SECURITY DEBRIEF</span>
          </div>

          <div className="mt-4 flex-1 overflow-y-auto max-h-[300px] pr-2">
            <FormattedDebrief text={aiDebrief} />
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono text-slate-400">Suspicious Core Phrases Detected:</span>
            {topSuspiciousKeywords.length === 0 ? (
              <span className="text-xs font-mono text-emerald-600 font-semibold">None Identified</span>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {topSuspiciousKeywords.map((kw, i) => (
                  <span
                    key={i}
                    className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded bg-rose-50 border border-rose-200 text-rose-700 animate-fade-in"
                  >
                    "{kw}"
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bento Grid: Dimension Scores */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Linguistic Scrutiny */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 relative group transition-all minimal-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-4 w-4 text-slate-400" />
              <h3 className="text-xs font-mono font-bold tracking-tight text-slate-500 uppercase">Linguistic Scrutiny</h3>
            </div>
            <span className={`text-xl font-mono font-bold ${getScoreColor(linguisticScore).text}`}>
              {linguisticScore}%
            </span>
          </div>
          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mb-3">
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{
                width: `${linguisticScore}%`,
                backgroundColor: getScoreColor(linguisticScore).fill
              }}
            ></div>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed font-mono">
            {linguisticDetails}
          </p>
        </div>

        {/* Temporal Distribution */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 relative group transition-all minimal-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-slate-400" />
              <h3 className="text-xs font-mono font-bold tracking-tight text-slate-500 uppercase">Temporal Distribution</h3>
            </div>
            <span className={`text-xl font-mono font-bold ${getScoreColor(temporalScore).text}`}>
              {temporalScore}%
            </span>
          </div>
          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mb-3">
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{
                width: `${temporalScore}%`,
                backgroundColor: getScoreColor(temporalScore).fill
              }}
            ></div>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed font-mono">
            {temporalDetails}
          </p>
        </div>

        {/* Reviewer Profiling */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 relative group transition-all minimal-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <UserCheck className="h-4 w-4 text-slate-400" />
              <h3 className="text-xs font-mono font-bold tracking-tight text-slate-500 uppercase">Reviewer Profiling</h3>
            </div>
            <span className={`text-xl font-mono font-bold ${getScoreColor(profileScore).text}`}>
              {profileScore}%
            </span>
          </div>
          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mb-3">
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{
                width: `${profileScore}%`,
                backgroundColor: getScoreColor(profileScore).fill
              }}
            ></div>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed font-mono">
            {profileDetails}
          </p>
        </div>
      </div>

      {/* Historical Timeline and Temporal Burst Tracker */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 minimal-shadow relative overflow-hidden">
        {/* Card Header with Metadata */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
          <div className="space-y-1">
            <h3 className="text-lg font-display font-bold text-slate-900 flex items-center space-x-2">
              <Clock className="h-5 w-5 text-purple-600" />
              <span>Temporal Velocity & Burst Tracker</span>
            </h3>
            <p className="text-xs text-slate-400 font-mono uppercase tracking-wider">
              Chronological frequency scanner for mapping review clusters and burst patterns
            </p>
          </div>
          
          <div className="flex items-center space-x-4 text-xs font-mono">
            <div className="flex items-center space-x-1.5">
              <span className="h-3 w-3 rounded bg-rose-500 inline-block border border-rose-600/10"></span>
              <span className="text-slate-600 font-medium">Flagged Reviews</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="h-3 w-3 rounded bg-emerald-500 inline-block border border-emerald-600/10"></span>
              <span className="text-slate-600 font-medium">Authentic Reviews</span>
            </div>
          </div>
        </div>

        {/* Dynamic Timeline Content */}
        {timelineData.length === 0 ? (
          <div className="py-12 text-center text-slate-400 font-mono text-xs">
            NO TEMPORAL DATE SEGMENTS DETECTED IN LOGS
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-stretch">
            {/* SVG Interactive Chart Column */}
            <div className="lg:col-span-3 flex flex-col justify-between">
              <div className="relative w-full overflow-x-auto select-none">
                {/* SVG Canvas with aspect ratio viewbox */}
                <svg viewBox="0 0 600 230" className="w-full min-w-[500px] h-auto">
                  {/* Grid lines */}
                  <line x1="40" y1="180" x2="560" y2="180" stroke="#e2e8f0" strokeWidth="1.5" />
                  <line x1="40" y1="135" x2="560" y2="135" stroke="#f1f5f9" strokeWidth="1" strokeDasharray="3,3" />
                  <line x1="40" y1="90" x2="560" y2="90" stroke="#f1f5f9" strokeWidth="1" strokeDasharray="3,3" />
                  <line x1="40" y1="45" x2="560" y2="45" stroke="#f1f5f9" strokeWidth="1" strokeDasharray="3,3" />

                  {/* Axis labels */}
                  <text x="32" y="183" textAnchor="end" className="text-[9px] font-mono fill-slate-400 font-bold">0</text>
                  <text x="32" y="138" textAnchor="end" className="text-[9px] font-mono fill-slate-400 font-bold">{Math.round(maxVal / 3)}</text>
                  <text x="32" y="93" textAnchor="end" className="text-[9px] font-mono fill-slate-400 font-bold">{Math.round((maxVal / 3) * 2)}</text>
                  <text x="32" y="48" textAnchor="end" className="text-[9px] font-mono fill-slate-400 font-bold">{maxVal}</text>

                  {/* Draw each bar */}
                  {timelineData.map((d, idx) => {
                    const spacing = 500 / timelineData.length;
                    const barWidth = Math.min(28, spacing * 0.55);
                    const x = 50 + idx * spacing + (spacing - barWidth) / 2;

                    // Compute stacked bar metrics
                    const isSelected = selectedTimelineDate === d.date;
                    const hasAnomaly = d.total >= 3 || (d.suspicious >= 2 && d.suspicious / d.total >= 0.6);

                    const genHeight = (d.genuine / maxVal) * 150;
                    const susHeight = (d.suspicious / maxVal) * 150;

                    // Hover background bar
                    const isHovered = hoveredTimelineDate === d.date;

                    return (
                      <g 
                        key={d.date}
                        className="cursor-pointer"
                        onClick={() => setSelectedTimelineDate(selectedTimelineDate === d.date ? null : d.date)}
                        onMouseEnter={() => setHoveredTimelineDate(d.date)}
                        onMouseLeave={() => setHoveredTimelineDate(null)}
                      >
                        {/* Interactive invisible full-height tap target rect */}
                        <rect 
                          x={x - (spacing - barWidth) / 4} 
                          y={15} 
                          width={spacing} 
                          height={180} 
                          fill="transparent" 
                        />

                        {/* Anomaly / Highlight Glow */}
                        {(isHovered || isSelected || hasAnomaly) && (
                          <rect
                            x={x - 4}
                            y={15}
                            width={barWidth + 8}
                            height={170}
                            fill={isSelected ? '#e0f2fe' : hasAnomaly ? '#fef2f2' : '#f8fafc'}
                            opacity={isSelected ? '0.6' : hasAnomaly ? '0.7' : '0.9'}
                            rx="4"
                            className="transition-all duration-200"
                          />
                        )}

                        {/* Stacking: Authentic on Bottom */}
                        {d.genuine > 0 && (
                          <rect
                            x={x}
                            y={180 - genHeight}
                            width={barWidth}
                            height={genHeight}
                            fill="#10b981"
                            rx={d.suspicious === 0 ? 3 : 0}
                            className="transition-all duration-500 ease-out"
                          />
                        )}

                        {/* Stacking: Suspicious on Top */}
                        {d.suspicious > 0 && (
                          <rect
                            x={x}
                            y={180 - genHeight - susHeight}
                            width={barWidth}
                            height={susHeight}
                            fill="#ef4444"
                            rx={3}
                            className="transition-all duration-500 ease-out"
                          />
                        )}

                        {/* Small alert beacon for Anomalies */}
                        {hasAnomaly && (
                          <g transform={`translate(${x + barWidth / 2 - 6}, ${180 - (d.total / maxVal) * 150 - 20})`}>
                            <circle cx="6" cy="6" r="6.5" fill="#fee2e2" stroke="#ef4444" strokeWidth="1.2" />
                            <path d="M 6,3.5 L 6,6.5 M 6,8.5 L 6,8.5" stroke="#ef4444" strokeWidth="1.5" strokeLinecap="round" />
                          </g>
                        )}

                        {/* Hover volume tooltips over bars */}
                        {isHovered && (
                          <g transform={`translate(${Math.max(40, Math.min(500, x + barWidth/2 - 50))}, ${Math.max(10, 180 - (d.total/maxVal)*150 - 45)})`}>
                            <rect width="100" height="32" fill="#0f172a" rx="4" />
                            <text x="50" y="14" textAnchor="middle" fill="#ffffff" className="text-[9px] font-bold font-mono">
                              {d.total} {d.total === 1 ? 'Review' : 'Reviews'}
                            </text>
                            <text x="50" y="24" textAnchor="middle" fill="#94a3b8" className="text-[8px] font-mono">
                              {d.suspicious} flagged | {d.genuine} auth
                            </text>
                          </g>
                        )}

                        {/* Date axis labels */}
                        <text
                          x={x + barWidth / 2}
                          y="198"
                          textAnchor="middle"
                          className={`text-[9.5px] font-mono transition-colors font-bold ${
                            isSelected ? 'fill-sky-600 font-extrabold' : 'fill-slate-500'
                          }`}
                        >
                          {formatDateLabel(d.date)}
                        </text>

                        {/* Weekday indicator dot / line */}
                        <circle
                          cx={x + barWidth / 2}
                          cy="180"
                          r="1.5"
                          className={isSelected ? 'fill-sky-500' : 'fill-slate-300'}
                        />
                      </g>
                    );
                  })}
                </svg>
              </div>
              
              <div className="text-[10px] text-slate-400 font-mono mt-2 flex items-center space-x-1.5">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-slate-300"></span>
                <span>Click on any date column to drill down and review individual entries in the table below.</span>
              </div>
            </div>

            {/* Sidebar Stats and Insights Panel */}
            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-4 flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <span className="text-[9px] font-mono font-bold tracking-widest text-slate-400 uppercase block">
                  TEMPORAL INSIGHTS
                </span>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-lg bg-white border border-slate-200/80 p-2.5 shadow-2xs">
                    <span className="text-[9px] font-mono text-slate-400 uppercase block font-semibold">Total Days</span>
                    <span className="text-lg font-display font-extrabold text-slate-800">{timelineData.length}</span>
                  </div>
                  <div className="rounded-lg bg-white border border-slate-200/80 p-2.5 shadow-2xs">
                    <span className="text-[9px] font-mono text-slate-400 uppercase block font-semibold">Peak Day</span>
                    <span className="text-xs font-mono font-bold text-slate-800 truncate block mt-1">
                      {formatDateLabel(peakDay?.date || 'N/A')}
                    </span>
                  </div>
                </div>

                {/* Anomalies alert list */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono font-bold tracking-widest text-slate-400 uppercase block">
                    ANOMALIES SPOTTED
                  </span>
                  {anomalies.length === 0 ? (
                    <div className="rounded-lg bg-emerald-50 border border-emerald-100 p-2.5 text-[11px] font-mono text-emerald-800 flex items-center space-x-1.5">
                      <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span>Zero burst anomalies identified. Dates are distributed securely.</span>
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1">
                      {anomalies.map((anom) => (
                        <div 
                          key={anom.date}
                          onClick={() => setSelectedTimelineDate(selectedTimelineDate === anom.date ? null : anom.date)}
                          className={`rounded-lg border p-2 text-[11px] font-mono flex flex-col cursor-pointer transition-all ${
                            selectedTimelineDate === anom.date 
                              ? 'bg-rose-100 border-rose-300 text-rose-900' 
                              : 'bg-rose-50 border-rose-100 text-rose-800 hover:border-rose-200'
                          }`}
                        >
                          <div className="flex items-center justify-between font-bold">
                            <span>🚨 {formatDateLabel(anom.date)}</span>
                            <span>{anom.total} Reviews</span>
                          </div>
                          <span className="text-[9.5px] text-rose-600 font-medium mt-0.5 leading-snug">
                            {anom.suspicious === anom.total 
                              ? '100% reviews flagged suspicious. Severe velocity hazard.' 
                              : `${Math.round((anom.suspicious / anom.total) * 100)}% reviews flagged. High-density burst.`}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Selected date preview widget */}
              {selectedTimelineDate && (
                <div className="rounded-lg bg-sky-50 border border-sky-100 p-3 text-[11px] font-mono text-sky-950 flex flex-col justify-between gap-2.5 animate-fade-in">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between font-extrabold text-sky-900">
                      <span>DRILLDOWN ACTIVE</span>
                      <button 
                        onClick={() => setSelectedTimelineDate(null)}
                        className="text-[10px] text-sky-600 hover:text-sky-800 underline font-bold"
                      >
                        RESET
                      </button>
                    </div>
                    <div className="text-slate-700">
                      Show reviews on <strong className="text-sky-950 font-bold">{formatDateLabel(selectedTimelineDate)}</strong>:
                    </div>
                    <div className="text-slate-600 text-[10px] leading-snug">
                      Total: {timelineData.find(d => d.date === selectedTimelineDate)?.total} reviews 
                      ({timelineData.find(d => d.date === selectedTimelineDate)?.suspicious} flagged, {timelineData.find(d => d.date === selectedTimelineDate)?.genuine} auth)
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Review Node Audit Table */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="space-y-1">
            <h3 className="text-lg font-display font-bold text-slate-900 flex items-center space-x-2">
              <FileText className="h-5 w-5 text-slate-400" />
              <span>Review Audit Log</span>
            </h3>
            <p className="text-xs text-slate-400 font-mono">SCANNED REVIEW BLOCKS AND INDIVIDUAL INTEGRITY RATINGS</p>
          </div>

          {/* Filter Controls */}
          <div className="flex flex-wrap gap-2 items-center">
            {/* Suspicion Filter */}
            <div className="flex rounded-lg bg-slate-100 border border-slate-200 p-0.5 text-[11px] font-mono">
              <button
                onClick={() => setFilter('all')}
                className={`px-3 py-1 rounded-md transition-all font-semibold cursor-pointer ${
                  filter === 'all' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                ALL ({reviews.length})
              </button>
              <button
                onClick={() => setFilter('suspicious')}
                className={`px-3 py-1 rounded-md transition-all font-semibold cursor-pointer ${
                  filter === 'suspicious' ? 'bg-rose-100/60 text-rose-700' : 'text-slate-500 hover:text-rose-700'
                }`}
              >
                FLAGGED ({reviews.filter(r => r.suspicionScore >= 40).length})
              </button>
              <button
                onClick={() => setFilter('genuine')}
                className={`px-3 py-1 rounded-md transition-all font-semibold cursor-pointer ${
                  filter === 'genuine' ? 'bg-emerald-100/60 text-emerald-700' : 'text-slate-500 hover:text-emerald-700'
                }`}
              >
                AUTHENTIC ({reviews.filter(r => r.suspicionScore < 40).length})
              </button>
            </div>

            {/* Rating Filter Dropdown */}
            <select
              value={ratingFilter}
              onChange={(e) => setRatingFilter(e.target.value === 'all' ? 'all' : Number(e.target.value))}
              className="rounded-lg bg-white border border-slate-200 px-3 py-1 text-[11px] font-mono text-slate-600 focus:outline-none focus:border-slate-400 cursor-pointer"
            >
              <option value="all">ALL RATINGS</option>
              <option value="5">5 STARS</option>
              <option value="4">4 STARS</option>
              <option value="3">3 STARS</option>
              <option value="2">2 STARS</option>
              <option value="1">1 STAR</option>
            </select>
          </div>
        </div>

        {/* Active Filters Summary */}
        {selectedTimelineDate && (
          <div className="flex items-center space-x-2 animate-fade-in py-1">
            <span className="text-[10px] font-mono text-slate-400 font-bold uppercase">Active Date Target:</span>
            <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-[10px] font-mono font-bold shadow-2xs">
              <span>{formatDateLabel(selectedTimelineDate)}</span>
              <button 
                onClick={() => setSelectedTimelineDate(null)}
                className="hover:text-sky-950 font-extrabold cursor-pointer ml-1 text-xs"
                title="Clear date filter"
              >
                ×
              </button>
            </span>
          </div>
        )}

        {/* Reviews List */}
        {filteredReviews.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-12 text-center text-slate-400 font-mono text-xs minimal-shadow">
            NO REVIEW BLOCKS MATCH THE CURRENT AUDIT FILTERS
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredReviews.map((review, i) => {
              const scoreStyles = getScoreColor(100 - review.suspicionScore);
              const isSuspicious = review.suspicionScore >= 40;

              return (
                <div
                  key={i}
                  className={`rounded-2xl border p-5 bg-white flex flex-col justify-between transition-all duration-300 select-text minimal-shadow ${
                    isSuspicious ? 'border-rose-200 shadow-sm hover:border-rose-300' : 'border-slate-100 hover:border-slate-200'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Header: Reviewer Info and Suspicion Score */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold text-slate-800 text-sm truncate max-w-[150px]">
                            {review.reviewerName}
                          </span>
                          {review.isVerified ? (
                            <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 border border-slate-200">
                              VERIFIED
                            </span>
                          ) : (
                            <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-50 text-slate-400 border border-slate-200/60">
                              UNVERIFIED
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] font-mono text-slate-400">{review.date}</span>
                      </div>

                      {/* Review Suspicion Rating Badge */}
                      <div className="text-right">
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${scoreStyles.bg} ${scoreStyles.border} ${scoreStyles.text}`}>
                          {isSuspicious ? 'RISK: ' : 'SAFE: '} {review.suspicionScore}%
                        </span>
                        <div className="text-[8px] font-mono text-slate-400 mt-1">SUSPICION PROBABILITY</div>
                      </div>
                    </div>

                    {/* Star Rating Indicator */}
                    <div className="flex items-center space-x-1">
                      {Array.from({ length: 5 }).map((_, starIdx) => (
                        <span
                          key={starIdx}
                          className={`text-xs ${
                            starIdx < review.rating ? 'text-amber-400' : 'text-slate-200'
                          }`}
                        >
                          ★
                        </span>
                      ))}
                      <span className="text-[10px] font-mono text-slate-400 ml-1.5">{review.rating} / 5</span>
                    </div>

                    {/* Review Title & Body */}
                    <div className="space-y-1">
                      <h4 className="font-display font-semibold text-slate-800 text-sm">{review.title}</h4>
                      <p className="text-xs text-slate-600 leading-relaxed pr-2 italic line-clamp-4 hover:line-clamp-none transition-all duration-300">
                        "{review.body}"
                      </p>
                    </div>
                  </div>

                  {/* Flagged Reasons (if suspicious) */}
                  {isSuspicious && review.suspicionReasons.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-rose-100 space-y-1.5 bg-rose-50/50 p-2.5 rounded-lg border border-rose-100/50">
                      <div className="flex items-center space-x-1.5 text-[9px] font-mono font-bold text-rose-700 uppercase tracking-wider">
                        <AlertTriangle className="h-3.5 w-3.5 text-rose-600 animate-pulse" />
                        <span>INTEGRITY FLAGS TRIGGERED:</span>
                      </div>
                      <ul className="list-disc pl-4 text-[10px] font-mono text-rose-800 space-y-0.5">
                        {review.suspicionReasons.map((reason, reasonIdx) => (
                          <li key={reasonIdx} className="leading-snug">
                            {reason}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Helpful votes */}
                  <div className="mt-4 pt-3 flex items-center justify-between text-[10px] font-mono text-slate-400 border-t border-slate-100">
                    <span className="flex items-center space-x-1">
                      <ThumbsUp className="h-3 w-3 text-slate-400" />
                      <span>{review.helpfulVotes || 0} helpful votes</span>
                    </span>
                    <span>LOG ID: N_{i + 100}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
