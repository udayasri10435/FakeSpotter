import { useState, useEffect } from 'react';
import { auth, db, signInWithGoogle, logout } from './firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { collection, query, where, orderBy, getDocs, addDoc, deleteDoc, doc, writeBatch, getDoc } from 'firebase/firestore';
import { ScanHistoryItem, ScanReport } from './types';
import Header from './components/Header';
import TerminalConsole from './components/TerminalConsole';
import ReportDashboard from './components/ReportDashboard';
import HistorySidebar from './components/HistorySidebar';
import { 
  ShieldCheck, 
  Search, 
  Sparkles, 
  Zap, 
  HelpCircle, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  ExternalLink,
  Lock,
  Compass
} from 'lucide-react';

export default function App() {
  // Auth state
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Pro and Credit states
  const [isPro, setIsPro] = useState(false);
  const [scansLeft, setScansLeft] = useState(5);
  const maxScans = 5;

  // Scan workflow states
  const [urlInput, setUrlInput] = useState('');
  const [scanning, setScanning] = useState(false);
  const [activeStep, setActiveStep] = useState('');
  const [logs, setLogs] = useState<{ status: string; message: string; timestamp: string }[]>([]);
  const [eventSource, setEventSource] = useState<EventSource | null>(null);

  // Loaded Report states
  const [activeReport, setActiveReport] = useState<{
    productName: string;
    domain: string;
    url: string;
    report: ScanReport;
    id?: string;
  } | null>(null);

  // History states
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Sample quick-test links for excellent UX
  const sampleLinks = [
    {
      title: 'Amazon TV Stick',
      url: 'https://www.amazon.com/All-new-Amazon-Fire-TV-Stick-4K/dp/B0C3RDGDFM',
    },
    {
      title: 'Airbnb Beach Cabin',
      url: 'https://www.airbnb.com/rooms/10492837-beachfront-boho-hideaway',
    },
    {
      title: 'Shopify Wool Coat',
      url: 'https://premium-apparel.shopify.com/products/vintage-overcoat-wool',
    }
  ];

  // 1. Listen to Auth Changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // 2. Load Credits & History based on Auth status
  useEffect(() => {
    // Determine source of state
    if (user) {
      loadHistoryFromFirestore(user.uid);
      loadCreditsFromLocalStorage(); // Fallback to localStorage or expand to user settings
    } else {
      loadHistoryFromLocalStorage();
      loadCreditsFromLocalStorage();
    }
  }, [user]);

  // 3. Check for Shared Report in URL query parameter on load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const reportId = params.get('reportId') || params.get('id');
    if (reportId) {
      const fetchSharedReport = async () => {
        try {
          const docRef = doc(db, 'scans', reportId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const data = docSnap.data();
            setActiveReport({
              id: docSnap.id,
              productName: data.productName,
              domain: data.domain,
              url: data.url,
              report: data.report
            });
          } else {
            // Check local storage fallback
            const saved = localStorage.getItem('fakespotter_scan_history');
            if (saved) {
              const items = JSON.parse(saved);
              const found = items.find((item: any) => item.id === reportId);
              if (found) {
                setActiveReport(found);
              }
            }
          }
        } catch (err) {
          console.error('Error fetching shared report from Firestore:', err);
        }
      };
      fetchSharedReport();
    }
  }, []);

  // Credit tracking
  const loadCreditsFromLocalStorage = () => {
    const today = new Date().toISOString().split('T')[0];
    const savedDate = localStorage.getItem('fakespotter_reset_date');
    const savedCredits = localStorage.getItem('fakespotter_scans_left');
    const savedPro = localStorage.getItem('fakespotter_is_pro') === 'true';

    setIsPro(savedPro);

    if (savedDate !== today) {
      // New day, reset credits
      localStorage.setItem('fakespotter_reset_date', today);
      localStorage.setItem('fakespotter_scans_left', String(maxScans));
      setScansLeft(maxScans);
    } else if (savedCredits !== null) {
      setScansLeft(Number(savedCredits));
    } else {
      setScansLeft(maxScans);
    }
  };

  const decrementCredits = () => {
    if (isPro) return;
    const nextCredits = Math.max(0, scansLeft - 1);
    setScansLeft(nextCredits);
    localStorage.setItem('fakespotter_scans_left', String(nextCredits));
  };

  const handleTogglePro = () => {
    const nextPro = !isPro;
    setIsPro(nextPro);
    localStorage.setItem('fakespotter_is_pro', String(nextPro));
  };

  // 3. History Persistence Logic
  const loadHistoryFromLocalStorage = () => {
    const saved = localStorage.getItem('fakespotter_scan_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        setHistory([]);
      }
    } else {
      setHistory([]);
    }
  };

  const loadHistoryFromFirestore = async (userId: string) => {
    try {
      const q = query(
        collection(db, 'scans'),
        where('userId', '==', userId),
        orderBy('timestamp', 'desc')
      );
      const querySnapshot = await getDocs(q);
      const items: ScanHistoryItem[] = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          id: docSnap.id,
          userId: data.userId,
          productName: data.productName,
          domain: data.domain,
          url: data.url,
          timestamp: data.timestamp?.toDate()?.toISOString() || new Date().toISOString(),
          report: data.report
        });
      });
      setHistory(items);
    } catch (err) {
      console.error('Error fetching from Firestore, falling back to local: ', err);
      loadHistoryFromLocalStorage();
    }
  };

  const saveScanToHistory = async (productName: string, domain: string, url: string, report: ScanReport) => {
    const newItem: Omit<ScanHistoryItem, 'id'> = {
      userId: user ? user.uid : 'guest',
      productName,
      domain,
      url,
      timestamp: new Date().toISOString(),
      report
    };

    if (user) {
      try {
        const docRef = await addDoc(collection(db, 'scans'), {
          ...newItem,
          timestamp: new Date() // Firestore Timestamp object
        });
        const savedItem: ScanHistoryItem = {
          ...newItem,
          id: docRef.id
        };
        setHistory(prev => [savedItem, ...prev]);
        setActiveReport({
          id: docRef.id,
          productName,
          domain,
          url,
          report
        });
      } catch (err) {
        console.error('Firestore save failed, saving locally: ', err);
        saveLocally(newItem);
      }
    } else {
      saveLocally(newItem);
    }
  };

  const saveLocally = (newItem: Omit<ScanHistoryItem, 'id'>) => {
    const savedItem: ScanHistoryItem = {
      ...newItem,
      id: String(Date.now())
    };
    const updated = [savedItem, ...history];
    setHistory(updated);
    localStorage.setItem('fakespotter_scan_history', JSON.stringify(updated));
    setActiveReport({
      id: savedItem.id,
      productName: newItem.productName,
      domain: newItem.domain,
      url: newItem.url,
      report: newItem.report
    });
  };

  const handleDeleteHistoryItem = async (id: string) => {
    if (user) {
      try {
        await deleteDoc(doc(db, 'scans', id));
        setHistory(prev => prev.filter(item => item.id !== id));
        if (activeReport?.id === id) setActiveReport(null);
      } catch (err) {
        console.error('Firestore delete failed: ', err);
      }
    } else {
      const updated = history.filter(item => item.id !== id);
      setHistory(updated);
      localStorage.setItem('fakespotter_scan_history', JSON.stringify(updated));
      if (activeReport?.id === id) setActiveReport(null);
    }
  };

  const handleClearAllHistory = async () => {
    if (user) {
      try {
        const q = query(collection(db, 'scans'), where('userId', '==', user.uid));
        const querySnapshot = await getDocs(q);
        // Clean with batch deletes
        const batch = writeBatch(db);
        querySnapshot.forEach((docSnap) => {
          batch.delete(docSnap.ref);
        });
        await batch.commit();
        setHistory([]);
        setActiveReport(null);
      } catch (err) {
        console.error('Firestore clear failed: ', err);
      }
    } else {
      setHistory([]);
      localStorage.removeItem('fakespotter_scan_history');
      setActiveReport(null);
    }
  };

  // 4. Trigger Scan Handler
  const handleInitiateScan = (urlToScan?: string) => {
    const targetUrl = urlToScan || urlInput;
    if (!targetUrl) return;

    // Fast validation
    try {
      new URL(targetUrl);
    } catch (_) {
      setError('Please provide a valid complete URL (including http/https).');
      return;
    }

    if (!isPro && scansLeft <= 0) {
      setError('Daily scan limit reached. Upgrade to Pro for unlimited AI scans!');
      return;
    }

    // Reset workflow states
    setError(null);
    setScanning(true);
    setActiveStep('connecting');
    setActiveReport(null);
    setLogs([]);

    const timestampStr = () => {
      const d = new Date();
      return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}:${d.getSeconds().toString().padStart(2, '0')}`;
    };

    const addLog = (status: string, msg: string) => {
      setLogs(prev => [...prev, { status, message: msg, timestamp: timestampStr() }]);
    };

    // Construct Server Sent Event Source
    const eventSourceUrl = `/api/scan-stream?url=${encodeURIComponent(targetUrl)}`;
    const source = new EventSource(eventSourceUrl);
    setEventSource(source);

    source.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const { status, message, data: payload } = data;

        if (status === 'error') {
          addLog('error', message);
          setError(message);
          setActiveStep('error');
          source.close();
          setScanning(false);
          return;
        }

        addLog(status, message);
        if (status !== 'done') {
          setActiveStep(status);
        } else {
          setActiveStep('done');
          source.close();
          setScanning(false);
          decrementCredits();

          // Handle complete report payload
          if (payload) {
            saveScanToHistory(payload.productName, payload.domain, payload.url, payload.report);
          }
        }
      } catch (err) {
        addLog('error', 'Failed to parse stream packet');
        setError('Audit protocol parse anomaly.');
        setScanning(false);
        source.close();
      }
    };

    source.onerror = () => {
      addLog('error', 'Connection terminated by remote host or missing API configuration.');
      setError('Scan connection closed unexpectedly. Ensure your GEMINI_API_KEY is configured.');
      setScanning(false);
      source.close();
    };
  };

  const handleAbortScan = () => {
    if (eventSource) {
      eventSource.close();
      setEventSource(null);
    }
    setScanning(false);
    setActiveStep('');
    setError('Audit scan manually terminated by user.');
  };

  const handleSelectHistoryItem = (item: ScanHistoryItem) => {
    setError(null);
    setScanning(false);
    setActiveReport({
      id: item.id,
      productName: item.productName,
      domain: item.domain,
      url: item.url,
      report: item.report
    });
  };

  // Auth wrappers
  const handleSignIn = async () => {
    try {
      setError(null);
      await signInWithGoogle();
    } catch (e: any) {
      setError(e.message || 'Google Sign-In failed');
    }
  };

  const handleSignOut = async () => {
    try {
      await logout();
      setActiveReport(null);
    } catch (e: any) {
      console.error(e);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans select-none relative overflow-x-hidden">
      {/* Header Widget */}
      <Header
        user={user}
        isPro={isPro}
        scansLeft={scansLeft}
        maxScans={maxScans}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onTogglePro={handleTogglePro}
      />

      {/* Main Container Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10 flex flex-col space-y-8 animate-fade-in">
        {/* Error Notification Banner */}
        {error && (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4 flex items-start space-x-3 text-rose-850 minimal-shadow">
            <AlertTriangle className="h-5 w-5 shrink-0 text-rose-600 mt-0.5" />
            <div className="flex-1 text-sm select-text">
              <span className="font-bold text-rose-950">System Alert:</span> {error}
            </div>
            <button 
              onClick={() => setError(null)}
              className="text-rose-600 hover:text-rose-800 font-bold px-1 text-xs font-mono cursor-pointer"
            >
              [X]
            </button>
          </div>
        )}

        {/* Dynamic Core Split: Primary Workstation (Left) vs History Cabin (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Workstation Column */}
          <div className="lg:col-span-3 space-y-6">
            {/* Input & Entry Control Bar */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 md:p-6 minimal-shadow relative overflow-hidden">
              <div className="space-y-4 max-w-2xl relative z-10">
                <div className="space-y-1">
                  <h1 className="text-xl md:text-2xl font-display font-bold text-slate-900 flex items-center space-x-2">
                    <Sparkles className="h-5 w-5 text-purple-600" />
                    <span>Initiate Review Integrity Audit</span>
                  </h1>
                  <p className="text-xs text-slate-500">
                    Paste the URL from Amazon, Shopify, Airbnb, or eBay. Our system will extract the reviews and perform deep linguistic and behavioral audit.
                  </p>
                </div>

                {/* Main URL input form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleInitiateScan();
                  }}
                  className="flex flex-col sm:flex-row gap-3.5"
                >
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Search className="h-4.5 w-4.5" />
                    </div>
                    <input
                      type="url"
                      required
                      disabled={scanning}
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      placeholder="Paste e-commerce or marketplace product URL here..."
                      className="w-full bg-slate-50 border border-slate-200 focus:border-slate-400 rounded-lg pl-10 pr-4 py-3 text-sm text-slate-800 placeholder-slate-400 focus:outline-none transition-all duration-200 select-text"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={scanning}
                    className="shrink-0 font-sans text-xs font-bold tracking-tight rounded-lg px-6 py-3 bg-slate-900 hover:bg-slate-850 text-white transition-all duration-200 disabled:opacity-50 select-none cursor-pointer"
                  >
                    {scanning ? 'SCANNING NODE...' : 'INITIATE DEEP SCAN'}
                  </button>
                </form>

                {/* Quick-test suggestions */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex items-center space-x-1">
                    <Compass className="h-3.5 w-3.5 text-slate-400" />
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-semibold">
                      Quick Audit Sandbox (Demo Links):
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {sampleLinks.map((link, idx) => (
                      <button
                        key={idx}
                        disabled={scanning}
                        onClick={() => {
                          setUrlInput(link.url);
                          handleInitiateScan(link.url);
                        }}
                        className="text-[10px] font-mono font-bold px-3 py-1.5 rounded-full border border-slate-200 bg-white text-slate-500 hover:text-slate-900 hover:border-slate-300 transition-all cursor-pointer"
                      >
                        {link.title}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Dynamic Interactive Stage Viewer: Hacking Console VS Audit Report */}
            {scanning ? (
              <TerminalConsole
                logs={logs}
                activeStep={activeStep}
                onAbort={handleAbortScan}
              />
            ) : activeReport ? (
              <ReportDashboard
                productName={activeReport.productName}
                domain={activeReport.domain}
                url={activeReport.url}
                report={activeReport.report}
                reportId={activeReport.id}
              />
            ) : (
              // Empty Workstation Welcome Screen
              <div className="rounded-2xl border border-dashed border-slate-200 p-12 text-center bg-white select-none minimal-shadow">
                <div className="max-w-md mx-auto space-y-5">
                  <div className="relative inline-flex h-12 w-12 items-center justify-center rounded-xl bg-slate-50 border border-slate-200 text-slate-700">
                    <ShieldCheck className="h-6 w-6 text-slate-800" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-display font-bold text-slate-800 text-base">Awaiting Active Audit Session</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Enter a product listing URL above to deploy our AI scanning web agent. Or, select a previous report from your audit log history to load results.
                    </p>
                  </div>
                  
                  {/* Informational Cards */}
                  <div className="grid grid-cols-2 gap-4 text-left pt-2 font-mono text-[10px]">
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                      <div className="text-slate-900 font-bold uppercase">TEMPORAL BURSTS</div>
                      <p className="leading-relaxed text-slate-500">Pinpoint perfect 5-star review clusters on specific days.</p>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                      <div className="text-slate-900 font-bold uppercase">BOT PATTERNS</div>
                      <p className="leading-relaxed text-slate-500">Scan semantic structures for repetitive copy-pasted texts.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar Audit Log Column */}
          <div className="lg:col-span-1">
            <HistorySidebar
              history={history}
              activeId={activeReport?.id || null}
              onSelect={handleSelectHistoryItem}
              onDelete={handleDeleteHistoryItem}
              onClearAll={handleClearAllHistory}
            />
          </div>
        </div>
      </main>

      {/* Footer Branding Credit */}
      <footer className="border-t border-slate-150 bg-white py-6 text-center text-[10px] font-mono text-slate-400 select-none mt-auto">
        <p>FAKESPOTTER IS AN INDEPENDENT SECURITY RESEARCH UTILITY. ALWAYS PERFORM PERSONAL DUE DILIGENCE.</p>
        <p className="mt-1 text-slate-500">POWERED BY GEMINI-3.1-PRO WITH HIGH INTELLIGENCE THINKING PROTOCOLS</p>
      </footer>
    </div>
  );
}
