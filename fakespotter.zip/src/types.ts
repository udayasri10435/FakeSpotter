export interface Review {
  reviewerName: string;
  rating: number;
  date: string;
  title: string;
  body: string;
  isVerified: boolean;
  helpfulVotes: number;
  suspicionScore: number;
  suspicionReasons: string[];
}

export interface ScanReport {
  trustScore: number;
  verdict: 'HIGHLY TRUSTWORTHY' | 'MODERATE RISK' | 'HIGHLY SUSPICIOUS';
  verdictSummary: string;
  aiDebrief: string;
  linguisticScore: number;
  linguisticDetails: string;
  temporalScore: number;
  temporalDetails: string;
  profileScore: number;
  profileDetails: string;
  topSuspiciousKeywords: string[];
  reviews: Review[];
}

export interface ScanHistoryItem {
  id?: string;
  userId: string;
  productName: string;
  domain: string;
  url: string;
  timestamp: any; // Firestore Timestamp or ISO string
  report: ScanReport;
}

export interface UserCredits {
  scansLeft: number;
  maxScans: number;
  isPro: boolean;
  lastResetDate: string; // YYYY-MM-DD
}
